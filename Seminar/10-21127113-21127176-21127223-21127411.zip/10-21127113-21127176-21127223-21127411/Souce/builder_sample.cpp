/*
 * Example of `builder' design pattern.
 *
 * Solution for manufacturing several types laptops,
 * each of which differentiate in its specifications.
 * (Central processing unit, Random access memory, Read-only memory)
 */

#include <iostream>
#include <string>

/* Laptop basic specifications */
class CPU{
    public:
        std::string name;
};

class ROM{
    public:
        int capacity;
};

class RAM{
    public:
        int capacity;
};

/* Product: a Laptop */
class Laptop{
    public:
        RAM* ram;
        ROM* rom;
        CPU* cpu;

        void specifications(){
            std::cout << "CPU: " << cpu->name << std::endl;
            std::cout << "ROM: " << rom->capacity << " GB" << std::endl;
            std::cout << "RAM: " << ram->capacity << " GB" << std::endl;
        }
};



/* Builder: responsible for constructing the smaller parts */
class Builder{
    public:
        virtual CPU* getCPU() = 0;
        virtual ROM* getROM() = 0;
        virtual RAM* getRAM() = 0;
};



/* Director: responsible for guiding the Builder what parts to constructs */
class Director{
    Builder* builder;

    public:
        void setBuilder(Builder *newBuilder){
            builder = newBuilder;
        }

        Laptop* getLaptop(){
            Laptop* laptop = new Laptop();
            
            laptop->cpu = builder->getCPU();
            laptop->rom = builder->getROM();
            laptop->ram = builder->getRAM();

            return laptop;
        }
};



/* Concrete Builder for Aspire 7 laptops */
class Aspire7Builder : public Builder{
    public:
        RAM* getRAM(){
            RAM* ram = new RAM();
            ram->capacity = 8;
            return ram;
        }

        ROM* getROM(){
            ROM* rom = new ROM();
            rom->capacity = 512;
            return rom;
        }

        CPU* getCPU(){
            CPU* cpu = new CPU();
            cpu->name = "AMD Ryzen 5 5500U";
            return cpu;
        }
};

/* Concrete builder for Lattitude 3420 laptops */
class Lattitude3420Builder : public Builder{
    public:
        RAM* getRAM(){
            RAM* ram = new RAM();
            ram->capacity = 8;
            return ram;
        }

        ROM* getROM(){
            ROM* rom = new ROM();
            rom->capacity = 256;
            return rom;
        }

        CPU* getCPU(){
            CPU* cpu = new CPU();
            cpu->name = "Intel I5-1135G7";
            return cpu;
        }
};

int main(){
    Laptop* laptop; // Complicated products
    Director director;

    /* Concrete builders */
    Aspire7Builder aspire7Builder;
    Lattitude3420Builder lattitude3420Builder;

    /* Build an Aspire 7 laptop */
    std::cout << "Aspire 7" << std::endl;
    director.setBuilder(&aspire7Builder); // using JeepBuilder instance
    laptop = director.getLaptop();
    laptop->specifications();

    std::cout << std::endl;

    /* Build a Lattitude 3420 laptop */
    std::cout << "Lattitude 3420" << std::endl;
    director.setBuilder(&lattitude3420Builder); // using NissanBuilder instance
    laptop = director.getLaptop();
    laptop->specifications();

    return 0;
}